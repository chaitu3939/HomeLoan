package com.lti.service;

import com.lti.model.Customer;
import com.lti.model.IncomeDetails;

public interface HomeLoanService {

	public boolean AddCustomer(Customer customer);
	
	public Customer verifyUser(String emailId,String password);
	public boolean userIncome(IncomeDetails incomeDetails);
}
