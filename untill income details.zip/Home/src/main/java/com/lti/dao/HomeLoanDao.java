package com.lti.dao;

import com.lti.model.Customer;
import com.lti.model.IncomeDetails;

public interface HomeLoanDao {

	public int createCustomer(Customer customer);
	public Customer verifyUser(String emailId,String password);
	public int userIncomeDetails(IncomeDetails incomeDetails);
}
