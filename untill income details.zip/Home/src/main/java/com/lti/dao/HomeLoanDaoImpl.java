package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Customer;
import com.lti.model.IncomeDetails;




@Repository
public class HomeLoanDaoImpl implements HomeLoanDao {

	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createCustomer(Customer customer) {
		
		customer=entityManager.merge(customer);
		entityManager.persist(customer);
		return 1;
	}

	@Override
	public Customer verifyUser(String emailId, String password) {
		String email=emailId;
		String pass=password;
		
		//Customer customer=entityManager.find(Customer.class,email);
		
		String jpql="select c from Customer c where c.emailId=:emailId";
		
		TypedQuery<Customer> tquery=entityManager.createQuery(jpql,Customer.class);
		//System.out.println(tquery);
		
		tquery.setParameter("emailId", emailId);
		 Customer customer=null;
		 customer = tquery.getSingleResult();
		
		String pin=customer.getPassword();
		
		if(pass.equals(pin)){
			return customer;
		}
		
		
		return null;
		}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int userIncomeDetails(IncomeDetails incomeDetails) {
		incomeDetails=entityManager.merge(incomeDetails);
		entityManager.persist(incomeDetails);
		return 1;
	}
	
	
	
	
	
	
}
