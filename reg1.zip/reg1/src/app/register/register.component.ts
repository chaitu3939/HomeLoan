import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormBuilder } from '@angular/forms';
import { Builder } from 'protractor';


@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  addForm:FormGroup;
  url:string="http://localhost:9090/homeloan";
  constructor(private http:HttpClient,private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.addForm=this.formBuilder.group({
      name:[''],
      gender:[''],
      email:[''],
      password:[''],
      mobile:[''],
      address:[''],
      aadhar:[''],
      pan:[''],
      bdate:['']
  });

}
addStudent():void{
  alert('add customer');
  this.http.post(this.url, this.addForm.value).subscribe(data=>{
    alert('customer  is added.');
  })
}
}
