package com.lti.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;
import com.lti.model.Tracker;





@Repository
public class HomeLoanDaoImpl implements HomeLoanDao {

	
	@PersistenceContext	
	private EntityManager entityManager;
	@Autowired
	private Tracker tracker;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createCustomer(Customer customer) {
		
		customer=entityManager.merge(customer);
		entityManager.persist(customer);
		return 1;
	}

	@Override
	public Customer verifyUser(String emailId, String password) {
		
		String pass=password;
		
		//Customer customer=entityManager.find(Customer.class,email);
		
		String jpql="select c from Customer c where c.emailId=:emailId";
		
		TypedQuery<Customer> tquery=entityManager.createQuery(jpql,Customer.class);
		//System.out.println(tquery);
		
		tquery.setParameter("emailId", emailId);
		 Customer customer=null;
		 customer = tquery.getSingleResult();
		
		String pin=customer.getPassword();
		
		if(pass.equals(pin)){
			return customer;
		}
		else{
		
		
		return null;
		}
		}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int userIncomeDetails(IncomeDetails incomeDetails) {
		
		
		
		
		incomeDetails=entityManager.merge(incomeDetails);
		entityManager.persist(incomeDetails);
		
		
		
		return 1;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int callBack(CallBack callBack) {
		
		callBack=entityManager.merge(callBack);
		entityManager.persist(callBack);
		return 1;
	}

	@Override
	public List<IncomeDetails> viewLoanRequests() {
		
		//String jpql="select i.loanId,i.status from incomeDetails i";
		String jpql ="from IncomeDetails";
		TypedQuery<IncomeDetails> tquery=entityManager.createQuery(jpql,IncomeDetails.class);
		
		List<IncomeDetails> incomeDetails=tquery.getResultList();
		
		return incomeDetails;
	}

	@Override
	public IncomeDetails GetStatus(int loanId) {
		String jpql="select i.status from IncomeDetails i where loanId=:loanId";
		TypedQuery<IncomeDetails> tquery=entityManager.createQuery(jpql,IncomeDetails.class);
		tquery.setParameter("loanId", loanId);
		
	IncomeDetails incomeDetails = tquery.getSingleResult();
		return incomeDetails;
	}
	
	
	
	
	
	
}
