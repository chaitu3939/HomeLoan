package com.lti.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.HomeLoanDao;
import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;
@Service("service")
public class HomeLoanServiceImpl implements HomeLoanService {

	@Autowired
	private HomeLoanDao dao;
	@Override
	public boolean AddCustomer(Customer customer) {
		int result=dao.createCustomer(customer);
		if(result==1){
			return true;
		}
		else
		return false;

	}
	@Override
	public Customer verifyUser(String emailId, String password) {
		Customer result=dao.verifyUser(emailId, password);
		
		return result;
	}
	@Override
	public boolean userIncome(IncomeDetails incomeDetails) {
		int result=dao.userIncomeDetails(incomeDetails);
		if(result==1){
			return true;
		}
		else
		return false;
	}
	@Override
	public boolean getCallBack(CallBack callBack) {
		int result =dao.callBack(callBack);
		if(result==1){
			return true;
		}else
		return false;
	}
	@Override
	public List<IncomeDetails> loanRequests() {
		
		return dao.viewLoanRequests();
	}
	@Override
	public IncomeDetails getLoanStatus(int loanId) {
		
		return dao.GetStatus(loanId);
	}

}
