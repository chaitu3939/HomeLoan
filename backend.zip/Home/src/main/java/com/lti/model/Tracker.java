package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("tracker")
@Scope(scopeName="prototype")
@Entity
@Table(name="tracker")
public class Tracker {

	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="sequence_tid")
	@SequenceGenerator(name="sequence_tid",sequenceName="loan_id")
	@Column(name="track_Id")
	private int trackId;
	
	@Column(name="loan_Id")
	private int loanId;
	
	@Column(name="loan_status")
	private String status;
	
	public Tracker() {
		super();
		
	}
	public Tracker(int trackId, int loanId, String status) {
		super();
		this.trackId = trackId;
		this.loanId = loanId;
		this.status = status;
	}
	public int getTrackId() {
		return trackId;
	}
	public void setTrackId(int trackId) {
		this.trackId = trackId;
	}
	public int getLoanId() {
		return loanId;
	}
	public void setLoanId(int loanId) {
		this.loanId = loanId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
