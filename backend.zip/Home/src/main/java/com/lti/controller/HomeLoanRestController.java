package com.lti.controller;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;
import com.lti.model.ResponseMessage;

import com.lti.service.HomeLoanService;

@RestController
@RequestMapping(path="homeloan")
@CrossOrigin
public class HomeLoanRestController {
	@Autowired
	private HomeLoanService service;
	

    private ResponseEntity<ResponseMessage> response;
	// http://localhost:9081/homeloan/addCustomer
	
	@RequestMapping(method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<ResponseMessage> addCustomer(@RequestBody Customer customer){
		ResponseEntity<ResponseMessage> response;
		boolean result=service.AddCustomer(customer);
		if(result){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is  added"),HttpStatus.CREATED);
		
		}else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not added"),HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		return response;
}
	//http://localhost:9081/homeloan/
	@RequestMapping(path="{emailId}/{password}" ,method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> checkCustomer(@PathVariable("emailId") String emailId,@PathVariable("password") String password){
		Customer result=service.verifyUser(emailId, password);
		
		
		if(result==null){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not registered"),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("login successfull"),HttpStatus.CREATED);
		}
		return response;
	}
	
	
	// http://localhost:9081/homeloan/incomeDetails
		@RequestMapping(path="incomeDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)

		public ResponseEntity<ResponseMessage> userIncome(@RequestBody IncomeDetails incomeDetails){
			ResponseEntity<ResponseMessage> response;
			boolean result=service.userIncome(incomeDetails);
			if(result){
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Income Details are  added"),HttpStatus.CREATED);
			
			}else{
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Income Details are not added"),HttpStatus.INTERNAL_SERVER_ERROR);
				
			}
			return response;
		
		}
		
		// http://localhost:9081/homeloan/callBack
		@RequestMapping(path="callBack",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<ResponseMessage> callBack(@RequestBody CallBack callBack){
			ResponseEntity<ResponseMessage> response;
			boolean result=service.getCallBack(callBack);
			if(result){
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("callBack details added"),HttpStatus.CREATED);
			}
			else{
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("callBack details are not added"),HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return response;
		}
		
		
		// http://localhost:9081/homeloan/viewLoan
		@RequestMapping(path="viewLoan",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
		public List<IncomeDetails> LoanDetails(){
			List<IncomeDetails> incomeDetails= service.loanRequests();
			return incomeDetails;
		}
		
		// http://localhost:9081/homeloan/status/
		@RequestMapping(path="{loanId}", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
		public IncomeDetails checkStatus(@PathVariable("loanId") int loanId){
			IncomeDetails incomeDetails=service.getLoanStatus(loanId);
			return incomeDetails;
			
		}
		
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> HandlerException(Exception ex){
		ResponseEntity<String> error=new ResponseEntity<String>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		return error;
	}
}
