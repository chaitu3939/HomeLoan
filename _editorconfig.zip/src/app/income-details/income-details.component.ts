import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";
import { HttpClient } from '@angular/common/http';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { AuthService } from '../services/auth.service';

@Component({
  selector: "app-income-details",
  templateUrl: "./income-details.component.html",
  styleUrls: ["./income-details.component.css"]
})
export class IncomeDetailsComponent implements OnInit {
  submitted = false;
  url: string = "http://192.168.12.31:9081/homeloan/incomedetails";
  constructor(private http: HttpClient, private formBuilder: FormBuilder, private authService: AuthService) { }


  addForm = new FormGroup({
    // firstName: new FormControl('', Validators.required),
    propertyLocation: new FormControl('', [Validators.required, Validators.minLength(6)]),
    organisationType: new FormControl('', [Validators.required]),
    propertyName: new FormControl(' ', [Validators.required, Validators.email]),
    customerName: new FormControl('', [Validators.required, Validators.minLength(6)]),
    estimatedAmount: new FormControl(' ', [Validators.required, Validators.minLength(10)]),
    typeOfEmployement: new FormControl('', [Validators.required])
    
  });


  ngOnInit() {
    console.log(this.addForm.get('customerName'))
    console.log(this.addForm)
  }
 
  // onSubmit() {
  //   // if(this.emailId===''|| this.password===''){
  //   //   alert("Fields cannot be empty");  
  //   // return 
  //   alert("successfully submitted")
  //    this.router.navigate(["/apply-loan"]);
    
  // }


  addincomedetails(): void {
    console.log(this.addForm.get('customerName'))
    console.log(this.addForm)
   this.submitted = true;
   // if (this.addForm.valid){
   //   this.authService.register(this.addForm.value).subscribe(data => {
   //     alert('customer is added');
   //   })
   alert('successfully submitted');
     this.http.post(this.url,this.addForm.value).subscribe(data=>{
       alert('successfully submitted');
     });
     //alert("error in submiting")
     
}
  }
