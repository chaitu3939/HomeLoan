import { Injectable } from "@angular/core";
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: "root"
})
export class AuthService {
  public isLoggedIn = false;

  baseUrl: 'http://localhost:9081/homeloan';
  emailId: string;
  password: string;

  constructor(private http:HttpClient) { }

  login(emailId:string,password:string) {
    return this.http.get(this.baseUrl + "/" + this.emailId + "/" + this.password);
  }
  
  // register(data) {
  //   return this.http.post(  this.baseUrl + '/register',data);
  // }
}
