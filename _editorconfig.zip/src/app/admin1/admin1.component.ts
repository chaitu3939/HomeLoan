import { Component, OnInit } from '@angular/core';
import { HttpClient } from "@angular/common/http";
import { Router } from "@angular/router";
@Component({
  selector: 'app-admin1',
  templateUrl: './admin1.component.html',
  styleUrls: ['./admin1.component.css']
})
export class Admin1Component implements OnInit {
  url: string = "http://192.168.12.31:9081/homeloan";
  loandetails:any;
  constructor( private http: HttpClient,
    private router: Router,) { }

  ngOnInit() {
  }

loanDetails():void{
 
  let url=this.url+"/viewLoan";
 this.http.get(url).subscribe(data => {

  this.loandetails=data;
 // alert(data);
});

}

approveStatus(loanId:any):void{
let url=this.url+"/changestatus"+"/"+loanId+"/approved";
alert(url);
this.http.get(url).subscribe(data => {

  

});
let ur=this.url+"/sendmail";
this.http.get(ur).subscribe(data => {

  alert("mali sent");

});
}

rejectStatus(loanId:any):void{
  let url=this.url+"/changestatus"+"/"+loanId+"/rejected";
  alert(url);
  this.http.get(url).subscribe(data => {

 
    alert();
  });
  }

}
