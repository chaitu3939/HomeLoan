import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-application-tracker',
  templateUrl: './application-tracker.component.html',
  styleUrls: ['./application-tracker.component.css']
})
export class ApplicationTrackerComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
