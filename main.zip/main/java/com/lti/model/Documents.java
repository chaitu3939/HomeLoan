package com.lti.model;

import javax.persistence.CascadeType;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

public class Documents {

	private byte[] salaryPaySlip;
	private byte[] voterId;
	private byte[] noObjectionCertificate;
	private byte[] agreementToSale;
	private byte[] letterOfAuthorization;
	
	@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="LoanId")
	private IncomeDetails incomeDetails;
}
