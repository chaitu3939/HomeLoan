package com.lti.model;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("customer")
@Scope(scopeName="prototype")
@Entity
@Table(name="customer1")
public class Customer {
	@Id
	//@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="sequence_cid")
	//@SequenceGenerator(name="sequence_cid",sequenceName="customer_id")
	@GeneratedValue
	
	@Column(name="customer_id")//auto generated
	private int customerId;
	
	@Column(name="customer_name")
	private  String customerName;
	
	@Column(name="gender")
	private String gender;
	@Column(name="email_id")
	private String emailId;
	@Column(name="password")
	private String password;
	@Column(name="phone_number")
	private long  phoneNo;
	@Column(name="address")
	private String address;
	@Column(name="adharcard")
	private String adhaarNo;
	@Column(name="pancard")
	private String panNo;
	@Column(name="age")
	private int age;
	@Column(name="nationality")
	private String nationality;
	
	
	
	
	public Customer() {
		super();
		
	}


	public Customer(int customerId, String customerName, String gender, String emailId, String password, long phoneNo,
			String address, String adhaarNo, String panNo, int age, String nationality) {
		super();
		this.customerId = customerId;
		this.customerName = customerName;
		this.gender = gender;
		this.emailId = emailId;
		this.password = password;
		this.phoneNo = phoneNo;
		this.address = address;
		this.adhaarNo = adhaarNo;
		this.panNo = panNo;
		this.age = age;
		this.nationality = nationality;
		
	}


	public int getCustomerId() {
		return customerId;
	}


	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}


	public String getCustomerName() {
		return customerName;
	}


	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}


	public String getGender() {
		return gender;
	}


	public void setGender(String gender) {
		this.gender = gender;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public long getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}


	public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getAdhaarNo() {
		return adhaarNo;
	}


	public void setAdhaarNo(String adhaarNo) {
		this.adhaarNo = adhaarNo;
	}


	public String getPanNo() {
		return panNo;
	}


	public void setPanNo(String panNo) {
		this.panNo = panNo;
	}


	public int getAge() {
		return age;
	}


	public void setAge(int age) {
		this.age = age;
	}


	public String getNationality() {
		return nationality;
	}


	public void setNationality(String nationality) {
		this.nationality = nationality;
	}


	





	
}