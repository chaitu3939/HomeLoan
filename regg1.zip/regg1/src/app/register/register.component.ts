import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FormGroup, FormBuilder, Validators } from '@angular/forms';



@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {
  addForm:FormGroup;
  url:string="http://localhost:9081/homeloan";
  constructor(private http:HttpClient,private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.addForm=this.formBuilder.group({
      customerName:['',Validators.required],
      gender:['',Validators.required],
      emailId:['',Validators.required],
      password:['',Validators.required],
      phoneNo:['',Validators.required],
      address:['',Validators.required],
      adhaarNo:['',Validators.required],
      panNo:['',Validators.required],
      age:['',Validators.required],
      nationality:['',Validators.required]
      
  });

}
addCustomer():void{
  alert('submit');
  this.http.post(this.url, this.addForm.value).subscribe(data=>{
    alert('customer  is added.');
  })
}
}
