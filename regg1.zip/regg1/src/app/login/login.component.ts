import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import {FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  addForm:FormGroup;
  url:string="http://localhost:9081/homeloan";
  constructor(private http:HttpClient,private formBuilder: FormBuilder) { }

  ngOnInit() {
    this.addForm=this.formBuilder.group({
      userName:[''],
      password:[''],
      
  });

  }
  loginCustomer():void{
    alert('submit');
    this.http.post(this.url, this.addForm.value).subscribe(data=>{
      alert('Successfull');
    })
}
}