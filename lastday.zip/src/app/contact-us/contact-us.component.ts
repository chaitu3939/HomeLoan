

import { Component, OnInit } from '@angular/core';
//import { HttpClient } from '@angular/core';
import {FormGroup,FormControl ,FormBuilder, Validators } from '@angular/forms';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-contact-us',
  templateUrl: './contact-us.component.html',
  styleUrls: ['./contact-us.component.css']
})
export class ContactUsComponent implements OnInit {
submmited =false;
url:string="http://localhost:9081/homeloan/callBack";
  constructor(private http:HttpClient,private formBulider:FormBuilder) { }

  callbackForm=new FormGroup ({
    // firstName: new FormControl('', Validators.required),
    Name:new FormControl(' ',[Validators.required,Validators.minLength(6)]),
      emailId:new FormControl(' ',[Validators.required, Validators.email]),
      phoneNo:new FormControl(' ',[Validators.required, Validators.minLength(10)]),
      message:new FormControl(' ',[Validators.required]) 
 });
  ngOnInit() {

  }

  callBack():void{
    console.log(this.callbackForm.get('name'))
    console.log(this.callbackForm)
    this.submmited=true;
    this.http.post(this.url,this.callbackForm.value).subscribe(data=>
      {
        alert('we will get back to you :)');
      })
  }

}

