package com.lti.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component("callBack")
@Scope(scopeName="prototype")
@Entity
@Table(name="call_back")
public class CallBack {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE ,generator="sequence_cid")
	@SequenceGenerator(name="sequence_cid",sequenceName="loan_id")
	@Column(name="call_back_id")//auto generated
	private int callBackId;
	@Column(name="name")
	private String name;
	@Column(name="email")
	private String emailId;
	@Column(name="phone_no")
	private long phoneNo;
	@Column(name="message")
	private String message;
	public CallBack() {
		super();
		
	}
	public CallBack(int callBackId, String name, String emailId, long phoneNo, String message) {
		super();
		this.callBackId = callBackId;
		this.name = name;
		this.emailId = emailId;
		this.phoneNo = phoneNo;
		this.message = message;
	}
	public int getCallBackId() {
		return callBackId;
	}
	public void setCallBackId(int callBackId) {
		this.callBackId = callBackId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	
	
	
	
}
