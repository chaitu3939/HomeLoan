package com.lti.model;

import java.util.Properties;
import java.util.Random;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.springframework.stereotype.Component;

@Component()
public class Functions {
//	private static final String String = null;

	

	public static boolean sendEmail(String recepient) {

		boolean mailSent = false;
		final String email = "komal.pinisetti@gmail.com";
		final String password = "rmsk1234";

		// Sender's email ID needs to be mentioned

		// Assuming you are sending email from localhost
//		String host = "localhost";

		Properties properties = new Properties();

		properties.put("mail.smtp.auth", "true");
		properties.put("mail.smtp.starttls.enable", "true");
		properties.put("mail.smtp.host", "smtp.gmail.com");
		properties.put("mail.smtp.port", "587");

		// Get system properties
		// Properties properties = System.getProperties();

		// Setup mail server
		// properties.setProperty("mail.smtp.host", host);

		// Get the default Session object.
		Session session = Session.getInstance(properties, new Authenticator() {

			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(email, password);
			}

		});

		Message message = prepareMessage(session, email, recepient);
		try {
			Transport.send(message);
			System.out.println("Sent message successfully....");
			mailSent = true;
		} catch (MessagingException e) {
			e.printStackTrace();
		}
		return mailSent;
	}

	private static Message prepareMessage(Session session, String email, String recepient) {
		MimeMessage message = new MimeMessage(session);
		try{
		// Set From: header field of the header.
			message.setFrom(new InternetAddress(email));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(recepient));
			message.setSubject("Mavericks Home Loans !");
			message.setText("Your Loan is Approved" );			
			return message;
		}
		catch(MessagingException e){
			System.out.println(e);
		}
			return null;
	}
}
