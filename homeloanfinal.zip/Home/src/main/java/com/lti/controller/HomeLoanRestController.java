package com.lti.controller;

import java.io.Serializable;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.Functions;
import com.lti.model.IncomeDetails;
import com.lti.model.ResponseMessage;

import com.lti.service.HomeLoanService;

@RestController
@RequestMapping(path="homeloan")
@CrossOrigin

public class HomeLoanRestController {
	@Autowired
	private HomeLoanService service;
	
	@Autowired
	private Functions app;
	

    private ResponseEntity<ResponseMessage> response;
	// http://localhost:9081/homeloan/addCustomer
	
	@RequestMapping(method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)

	public ResponseEntity<ResponseMessage> addCustomer(@RequestBody Customer customer){
		ResponseEntity<ResponseMessage> response;
		boolean result=service.AddCustomer(customer);
		if(result){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is  added"),HttpStatus.CREATED);
		
		}else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not added"),HttpStatus.INTERNAL_SERVER_ERROR);
			
		}
		return response;
}
	//http://localhost:9081/homeloan/
	@RequestMapping(path="{emailId}/{password}" ,method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
	public ResponseEntity<ResponseMessage> checkCustomer(@PathVariable("emailId") String emailId,@PathVariable("password") String password){
		Customer result=service.verifyUser(emailId, password);
		
		
		if(result==null){
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not registered"),HttpStatus.INTERNAL_SERVER_ERROR);
		}
		else{
			response=new ResponseEntity<ResponseMessage>(new ResponseMessage("login successfull"),HttpStatus.CREATED);
		}
		return response;
	}
	
	
	// http://localhost:9081/homeloan/incomeDetails
		@RequestMapping(path="incomeDetails",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)

		public ResponseEntity<ResponseMessage> userIncome(@RequestBody IncomeDetails incomeDetails){
			ResponseEntity<ResponseMessage> response;
			boolean result=service.userIncome(incomeDetails);
			if(result){
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Income Details are  added"),HttpStatus.CREATED);
			
			}else{
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("Income Details are not added"),HttpStatus.INTERNAL_SERVER_ERROR);
				
			}
			return response;
		
		}
		
		// http://localhost:9081/homeloan/callBack
		@RequestMapping(path="callBack",method=RequestMethod.POST,consumes=MediaType.APPLICATION_JSON_VALUE)
		public ResponseEntity<ResponseMessage> callBack(@RequestBody CallBack callBack){
			ResponseEntity<ResponseMessage> response;
			boolean result=service.getCallBack(callBack);
			if(result){
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("callBack details added"),HttpStatus.CREATED);
			}
			else{
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("callBack details are not added"),HttpStatus.INTERNAL_SERVER_ERROR);
			}
			return response;
		}
		
		
		// http://localhost:9081/homeloan/viewLoan
		@RequestMapping(path="viewLoan",method=RequestMethod.GET, produces=MediaType.APPLICATION_JSON_VALUE)
		public List<IncomeDetails> LoanDetails(){
			List<IncomeDetails> incomeDetails= service.loanRequests();
			return incomeDetails;
		}
		
		// http://localhost:9081/homeloan/status/
		@RequestMapping(path="status/{loanId}", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
		public IncomeDetails checkStatus(@PathVariable("loanId") int loanId){
			IncomeDetails incomeDetails=service.getLoanStatus(loanId);
			return incomeDetails;
			
		}
		
		// http://localhost:9081/homeloan/changestatus
		
		@RequestMapping(path="changestatus/{loanId}/{approve}", method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)
		public void  changeStatus(@PathVariable("loanId") int loanId,@PathVariable("approve") String status){
			
			service.changeStatus(loanId,status);
		}
		
		
		
		// http://localhost:9081/homeloan/emailOTP/
		@RequestMapping(path="emailOTP",method=RequestMethod.GET,produces=MediaType.APPLICATION_JSON_VALUE)                                     //SEND OTP
		public ResponseEntity<ResponseMessage> sendEmail(){

			String email=service.fetchemail();
			System.out.println(email);
			boolean result=app.sendEmail(email);
			 
			if(result==true){
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("customer is not registered"),HttpStatus.NOT_FOUND);
			}
			else{
				response=new ResponseEntity<ResponseMessage>(new ResponseMessage("login successfull"),HttpStatus.FOUND);
			}
			return response;
		

		
		}
		
	
	
	@ExceptionHandler(Exception.class)
	public ResponseEntity<String> HandlerException(Exception ex){
		ResponseEntity<String> error=new ResponseEntity<String>(ex.getMessage(),HttpStatus.INTERNAL_SERVER_ERROR);
		return error;
	}
}
