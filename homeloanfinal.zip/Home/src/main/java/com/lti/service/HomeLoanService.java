package com.lti.service;

import java.util.List;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;

public interface HomeLoanService {

	public boolean AddCustomer(Customer customer);
	
	public Customer verifyUser(String emailId,String password);
	public boolean userIncome(IncomeDetails incomeDetails);
	
	public boolean getCallBack(CallBack callBack);
	public  List<IncomeDetails> loanRequests();

	public IncomeDetails getLoanStatus(int loanId);

	public void changeStatus(int loanId, String status);

	public String fetchemail();
	
}
