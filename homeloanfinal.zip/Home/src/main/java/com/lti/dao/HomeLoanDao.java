package com.lti.dao;

import java.util.List;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;

public interface HomeLoanDao {

	public int createCustomer(Customer customer);
	public Customer verifyUser(String emailId,String password);
	public int userIncomeDetails(IncomeDetails incomeDetails);
	public int callBack(CallBack callBack);
	public List<IncomeDetails> viewLoanRequests();
	public IncomeDetails GetStatus(int loanId);
	public void approveLoan(int loanId, String status);
	public String findEmail();
	
}
