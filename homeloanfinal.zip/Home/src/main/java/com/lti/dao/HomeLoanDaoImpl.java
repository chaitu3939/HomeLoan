package com.lti.dao;

import java.util.List;


import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.CallBack;
import com.lti.model.Customer;
import com.lti.model.IncomeDetails;
import com.lti.model.Tracker;





@Repository
public class HomeLoanDaoImpl implements HomeLoanDao {

	
	@PersistenceContext	
	private EntityManager entityManager;
	@Autowired
	private Tracker tracker;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createCustomer(Customer customer) {
		
		customer=entityManager.merge(customer);
		entityManager.persist(customer);
		return 1;
	}

	@Override
	public Customer verifyUser(String emailId, String password) {
		
		String pass=password;
		
		
		
		String jpql="select c from Customer c where c.emailId=:emailId";
		
		TypedQuery<Customer> tquery=entityManager.createQuery(jpql,Customer.class);
		
		
		tquery.setParameter("emailId", emailId);
		 Customer customer=null;
		 customer = tquery.getSingleResult();
		
		String pin=customer.getPassword();
		
		if(pass.equals(pin)){
			return customer;
		}
		else{
		
		
		return null;
		}
		}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int userIncomeDetails(IncomeDetails incomeDetails) {
		
		
		
		
		incomeDetails=entityManager.merge(incomeDetails);
		entityManager.persist(incomeDetails);
		
		
		
		return 1;
	}

	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int callBack(CallBack callBack) {
		
		callBack=entityManager.merge(callBack);
		entityManager.persist(callBack);
		return 1;
	}

	@Override
	@Transactional
	public List<IncomeDetails> viewLoanRequests() {
		
		String status="pending";
		String jpql="select i from IncomeDetails i where i.status=:status";
		//String jpql ="from IncomeDetails";
		TypedQuery<IncomeDetails> tquery=entityManager.createQuery(jpql,IncomeDetails.class);
		tquery.setParameter("status", status);
		
		List<IncomeDetails> incomeDetails=tquery.getResultList();
		
		return incomeDetails;
	}

	@Override
	public IncomeDetails GetStatus(int loanId) {
		
		String jpql="select i.status from IncomeDetails i where i.loanId=:loanId";
		TypedQuery<IncomeDetails> tquery=entityManager.createQuery(jpql,IncomeDetails.class);
		tquery.setParameter("loanId", loanId);
		
	IncomeDetails incomeDetails = tquery.getSingleResult();
		return incomeDetails;
	}

	@Override
	@Transactional
	public void approveLoan(int loanId, String status) {
		System.out.println("change status");
		String jpql="update IncomeDetails i set i.status=:status where i.loanId=:loanId";
		Query tquery=entityManager.createQuery(jpql);
		tquery.setParameter("loanId", loanId);
		tquery.setParameter("status", status);
		System.out.println("IN");
		int result=tquery.executeUpdate();
		System.out.println(result);
	}

	@Override
	public String findEmail() {
		System.out.println("email");
		String jpql="select c from Customer c where c.customerName=:customerName";
		String customerName="chaitanya";
		TypedQuery<Customer> tquery=entityManager.createQuery(jpql,Customer.class);
		tquery.setParameter("customerName", customerName);
		Customer customer=tquery.getSingleResult();
		System.out.println(customer);
		return customer.getEmailId();
		
	}
	
	
	
	
	
	
}
