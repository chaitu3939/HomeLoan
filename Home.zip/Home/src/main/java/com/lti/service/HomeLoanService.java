package com.lti.service;

import com.lti.model.Customer;

public interface HomeLoanService {

	public boolean AddCustomer(Customer customer);
}
