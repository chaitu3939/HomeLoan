package com.lti.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.lti.dao.HomeLoanDao;
import com.lti.model.Customer;
@Service("service")
public class HomeLoanServiceImpl implements HomeLoanService {

	@Autowired
	private HomeLoanDao dao;
	@Override
	public boolean AddCustomer(Customer customer) {
		int result=dao.createCustomer(customer);
		if(result==1){
			return true;
		}
		else
		return false;

	}
	@Override
	public int verifyUser(String emailId, String password) {
		int result=dao.verifyUser(emailId, password);
		
		if(result==0){
			return 0;
		}
		else if(result==1){
		return 1;
		}
		else{
			return 2;
		}
	}

}
