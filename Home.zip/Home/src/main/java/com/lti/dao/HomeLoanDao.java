package com.lti.dao;

import com.lti.model.Customer;

public interface HomeLoanDao {

	public int createCustomer(Customer customer);
}
