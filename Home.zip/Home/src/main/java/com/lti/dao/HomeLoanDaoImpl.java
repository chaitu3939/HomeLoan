package com.lti.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.lti.model.Customer;


@Repository
public class HomeLoanDaoImpl implements HomeLoanDao {

	
	@PersistenceContext	
	private EntityManager entityManager;
	
	@Override
	@Transactional(propagation=Propagation.REQUIRED)
	public int createCustomer(Customer customer) {
		
		customer=entityManager.merge(customer);
		entityManager.persist(customer);
		return 1;
	}
	
}
