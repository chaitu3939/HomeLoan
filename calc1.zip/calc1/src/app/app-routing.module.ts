import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';
import { EligibilityComponent } from './eligibility/eligibility.component';


const routes: Routes = [
  {path:'emi',component:EmicalculatorComponent},
  {path:'elig',component:EligibilityComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
