import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmicalculatorComponent } from './emicalculator/emicalculator.component';
import { FormsModule} from '@angular/forms';
import { EligibilityComponent } from './eligibility/eligibility.component';

@NgModule({
  declarations: [
    AppComponent,
    EmicalculatorComponent,
    EligibilityComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
