import { Component, OnInit } from "@angular/core";
import { HttpClient } from "@angular/common/http";
import { FormGroup } from "@angular/forms";
import { Router } from "@angular/router";
import { AuthService } from "../services/auth.service";

@Component({
  selector: "app-login",
  templateUrl: "./login.component.html",
  styleUrls: ["./login.component.css"]
})
export class LoginComponent implements OnInit {
  addForm: FormGroup;
  
  emailId: string;
  password: string;
  result: any;

  constructor(
   // private http: HttpClient,
    private router: Router,
    private authService: AuthService
  ) {}

  ngOnInit() {}
  loginCustomer(): void {
    
    if(this.emailId===''|| this.password===''){
      alert("Fields cannot be empty");  
    return
  }
    
    /**for testing purpose hardcoded */
    if (this.emailId === "test@test.com" && this.password === "test") {
      localStorage.setItem("isLoggedIn", "true");
      this.router.navigate(["/apply-loan"]);
      this.authService.isLoggedIn = true;
    }

    // let url = this.url + "/" + this.emailId + "/" + this.password;
    // alert(url);
   
     
    
    this.authService.login(this.emailId,this.password).subscribe(data => {
      alert("Successfull");

      /** below line to store the user log data and to redirect to home page */
      localStorage.setItem("isLoggedIn", "true");
      this.result = data;
      this.router.navigate(["/apply-loan"]);
      this.authService.isLoggedIn = true;
    });
  }
}
